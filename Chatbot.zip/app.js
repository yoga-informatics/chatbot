const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();

app.use(express.static("public"));
app.use(bodyParser.json());
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));


function chatbotLocal(message) {
  message = message.toLowerCase();

  if (message.includes("hai") || message.includes("halo") || message.includes("hello")) {
    return "Halo! Ada yang bisa saya bantu?";
  }
  if (message.includes("nama")) {
    return "Saya chatbot sederhana tanpa API, dibuat untuk demo psikotest.";
  }
  if (message.includes("buat apa") || message.includes("fungsi")) {
    return "Saya berfungsi sebagai chatbot lokal tanpa AI eksternal.";
  }
  if (message.includes("terima kasih")) {
    return "Sama-sama! Senang bisa membantu.";
  }

  return "Maaf, saya belum mengerti. Saya hanya chatbot lokal tanpa API.";
}

app.get("/", (req, res) => {
  res.render("chat");
});

app.post("/ask", (req, res) => {
  const userMessage = req.body.message;
  const reply = chatbotLocal(userMessage);
  res.json({ reply });
});

app.listen(3000, () => console.log("Chatbot running at http://localhost:3000"));
